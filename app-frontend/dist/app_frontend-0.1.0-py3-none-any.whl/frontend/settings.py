from yarl import URL


TITLE = "Energy Consumption Forecasting"
API_URL = URL("http://34.68.213.190:8001/api/v1")
