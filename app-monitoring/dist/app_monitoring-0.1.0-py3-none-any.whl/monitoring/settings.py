from yarl import URL


TITLE = "Monitoring | Energy Consumption"
API_URL = URL("http://34.68.213.190:8001/api/v1")
